<?php
/* Smarty version 3.1.30, created on 2018-11-19 14:03:46
  from "/users/a54375/public_html/LAB11/application/views/templates/register_template.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5bf2c2c296b267_60937535',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '640d850f2ea6281836194d8c3fd87432c635a309' => 
    array (
      0 => '/users/a54375/public_html/LAB11/application/views/templates/register_template.tpl',
      1 => 1542636057,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bf2c2c296b267_60937535 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sign Up</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</head>
<body>

<nav class="navbar navbar-inverse" style=background-color:green;border-color:green;color:white;height:70px>
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="https://png.icons8.com/cotton/2x/golf-ball.png" style="height:60px;width: 60px;margin-top:5%">

    
</div>
    <ul class="nav navbar-nav">
	<!-- BEGIN TOP -->
      <li><a href="http://all.deei.fct.ualg.pt/~a54375/LAB11/index.php/blog/" style="color:lightgray;font-size:20px;margin-top:4%;"><?php echo $_smarty_tpl->tpl_vars['MENU_1']->value;?>
</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="http://all.deei.fct.ualg.pt/~a54375/LAB11/index.php/blog/login" style="font-size:16px;margin-top:10%;"> <span class="glyphicon glyphicon-log-in"></span> <?php echo $_smarty_tpl->tpl_vars['MENU_2']->value;?>
</a></li>
      <li><a href="http://all.deei.fct.ualg.pt/~a54375/LAB11/index.php/blog/register" style="font-size:16px;margin-top:15%;"><?php echo $_smarty_tpl->tpl_vars['MENU_3']->value;?>
</a></li>
	<!-- END TOP -->

    </ul>
  </div>
</nav>


<div class="panel panel-default" style="background-color:<?php echo $_smarty_tpl->tpl_vars['COLOR']->value;?>
;color:whitesmoke; border:<?php echo $_smarty_tpl->tpl_vars['COLOR']->value;?>
">
  <h3 style="text-align: center"><?php echo $_smarty_tpl->tpl_vars['MESSAGE']->value;?>
</h3>
</div>


<div class="panel panel-default" style="margin-left: 20%;margin-right: 20%;margin-top:2%;background-color:white;">
    <h1 style="text-align:center">Sign Up</h1>
	<form action="<?php echo $_smarty_tpl->tpl_vars['register']->value;?>
" method="post" id="form">
    	<!-- BEGIN FORM -->
        <div class="form-group">
          <label for="name">Name:</label>
          <input type="name" class="form-control" name="n" value="<?php echo $_smarty_tpl->tpl_vars['NOME']->value;?>
">
          
        </div>
        <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" name="email" value="<?php echo $_smarty_tpl->tpl_vars['EMAIL']->value;?>
">
              </div>
              	<!-- END FORM -->
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input type="password" class="form-control" name="pwd">
        </div>
        <div class="form-group">
                <label for="pwd">Password confirmation:</label>
                <input type="password" class="form-control" name="confirmpwd">
              </div>
        <div class="align:center-block" style="margin-left:45%;">
            <button type="submit" class="btn btn-default" style="background-color:blue;color:white;margin-bottom:3%" formid="form">Go</button>
            <button type="reset" class="btn btn-default" style="background-color:rgb(175, 18, 18);color:white;margin-bottom:3%">Clear</button>
        </div>
      </form>

</div>
<footer>
  <div class="page-header">
    <div class="pull-left" style="margin-left:10%">
    <h6>2018 Desenvolvimento de Aplicacoes Web</h6>
    </div>
    <div class="pull-right" style="margin-right:10%">
    <h6 class="text-right" >Designed by Miguel Cristina</h6>
    </div>
    <div class="clearfix"></div>
  </div>
</footer>   
</div>
</body>
</html><?php }
}
