<?php
/* Smarty version 3.1.30, created on 2018-11-19 10:43:57
  from "/users/a54375/public_html/LAB11/application/views/templates/message_template.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5bf293ede7f9c0_91042950',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '22e8dadb4e8f3c0e42037ec46f79da03b3c3e375' => 
    array (
      0 => '/users/a54375/public_html/LAB11/application/views/templates/message_template.tpl',
      1 => 1542624164,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bf293ede7f9c0_91042950 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Cya soon!</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</head>
<body>
    <div class="page-wrap d-flex flex-row align-items-center">
        <div class="container">
	<div class="row justify-content-center">
	<div class="col-md-12 text-center">
	<img src="https://png.icons8.com/cotton/2x/golf-ball.png" style="height:80px;width: 80px;margin-top:5%">
	</div>	
	</div>
            <div class="row justify-content-center">
                <div class="col-md-12 text-center">
                    <span class="display-1 d-block">From THE CLUB HOUSE staff:</span>
              
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo $_smarty_tpl->tpl_vars['MESSAGE']->value;?>

                      </div>
         
			<meta http-equiv="refresh" content="5; url=index" />
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php }
}
