<?php
/* Smarty version 3.1.30, created on 2018-11-15 15:33:52
  from "/users/a54375/public_html/LAB9_10/application/views/templates/blog_template.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5bed91e013d990_13798034',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2df7fb94a2238c5309c5ff4625a23dc0a828ca4a' => 
    array (
      0 => '/users/a54375/public_html/LAB9_10/application/views/templates/blog_template.tpl',
      1 => 1542295939,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bed91e013d990_13798034 (Smarty_Internal_Template $_smarty_tpl) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Miguel Cristina's DAW Forum</title>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</head>
<body>

<nav class="navbar navbar-inverse" style="background-color: green;border-color: green;color:white;height:70px ">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="https://png.icons8.com/cotton/2x/golf-ball.png" style="height:60px;width: 60px;margin-top:5%">
    </div>
    <ul class="nav navbar-nav">
      
      <li><a href="index" style="color:lightgray;font-size:20px;margin-top:10%;"><?php echo $_smarty_tpl->tpl_vars['MENU_1']->value;?>
</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
    
      <li><a href="blog"style="font-size:16px;margin-top:10%;"><?php echo $_smarty_tpl->tpl_vars['MENU_4']->value;?>
</a></li>



    </ul>
  </div>
</nav>
 
<!-- BEGIN MENU -->
<div class="panel panel-default" style="margin-left: 5%;margin-right: 5%;margin-top:2%;border-color:green" >
  <div class="row">
    <div class="col-lg-12"></div>
    <form action="post?blog_id=<?php echo $_smarty_tpl->tpl_vars['blog_id']->value;?>
" method="post" formid="blogform">
<textarea name="content" style="width:1200px; height:200px;margin-left:6%;margin-top:5%;margin-bottom:5%"><?php echo $_smarty_tpl->tpl_vars['BLOG']->value;?>
</textarea >
  </div>
  <div class="row">
    <div class="col-lg-12">
        <div class="align:center-block" style="margin-left:45%;">
            <button type="submit" class="btn btn-default" style="background-color:green;color:white;margin-bottom:3%" formid="blogform" >Go</button>
            <button type="reset" class="btn btn-default" style="background-color:rgb(175, 18, 18);color:white;margin-bottom:3%">Cancel</button></form>
        </div>
      </div>
    </div>
      </div>
<div class="row">
  <div class="col-lg-12">
      <div class="panel panel-default" style="margin-left: 0.5%;margin-right: 0.5%;border-color: grey">
          
    </div>
    </div>
</div>
</div>

<!-- END MENU -->
<footer>
        <div class="page-header">
                <div class="pull-left" style="margin-left:10%">
                <h6>2018 Desenvolvimento de Aplicacoes Web</h6>
                </div>
                <div class="pull-right" style="margin-right:10%">
                <h6 class="text-right" >Designed by Miguel Cristina</h6>
                </div>
                <div class="clearfix"></div>
              </div>
              
</footer>   
</body>
</html><?php }
}
