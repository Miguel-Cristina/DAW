<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Blog extends CI_Controller {
	public function __construct()
 	{
 		parent::__construct();
 		$this->load->model('Blog_model');
 		$this->load->helper('url');
 		$this->load->library('session');
 	}
 	public function index()
 	{	 

		if(isset($_SESSION['name']))
		{
        	$data['WELCOME'] = 'Welcome ';
       	 	$data['MENU_4'] = 'Post blog';
       	 	$data['MENU_2'] = 'Sign out';
			$data['MENU_1'] = 'Home';
			$data['LINK'] = site_url().'/blog/logout';
			$data['LINK2'] = site_url().'/blog/post/';
			$data['USER'] = $_SESSION['name'];
			$data['session_id'] = $_SESSION['id'];
			$data['POSTLINK'] = 'post';
			$data['POST'] = 'Update blog';
			
		} 
		else
		{
			$data['MENU_1'] = 'Home';
			$data['MENU_4'] = 'Sign in';
			$data['MENU_2'] = 'Log in';
			$data['LINK'] = site_url().'/blog/login';
			$data['LINK2'] = site_url().'/blog/register';

		}
		$data['blogs'] = $this->Blog_model->get_posts();
		
		$string='{$blogs[bl].id}';
		for($i=0; $i<count($data['blogs']); $i++) 
		{
			$blog_replies[$i] =  $this->Blog_model->get_replies($data['blogs'][$i]['id']);			
		}
		$data['replies'] = $blog_replies;
		
		$this->smarty->view('index_template.tpl', $data);
	}

	public function register()
 	{
       	$data['MENU_2'] = 'Login';
		$data['MENU_1'] = 'Home';
		$data['MENU_3'] = 'Sign in';
 		$this->load->helper(array('form', 'url'));
       	$this->load->library('form_validation'); 
       	$this->form_validation->set_rules('pwd', 'Password', 'required');
     	$this->form_validation->set_rules('confirmpwd', 'Password Confirmation', 'required|matches[pwd]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
 		if($this->form_validation->run() == FALSE)
 		{
			$data['COLOR'] = 'firebrick';
			$data['MESSAGE'] = validation_errors();

 			$this->smarty->view('application/views/templates/register_template.tpl', $data); 
 		}
 		else
 		{
			$clientName = $this->input->post('n');
        		$clientEmail = $this->input->post('email');
        		$pass = $this->input->post('pwd'); 
            
        		$password = substr(md5($pass),0,32);  
        		$update = date("Y-m-d H:i:s");     
            		$FormData = array(
             			 'name' => $clientName,
              			 'email' => $clientEmail,
              			 'pass' => $password,
               			 'update' => $update
           		);
            		
 			$this->Blog_model->register_user($FormData); 
 			$data['MESSAGE']='Success: New user registered';
 			$this->smarty->view('message_template.tpl');
 		}
			
 	}
		public function login() 
    	{ 
      	
     		$this->load->helper(array('form', 'url'));
      		$this->load->library('form_validation');
      		$this->form_validation->set_rules('pwd', 'Password', 'required');
      		$this->form_validation->set_rules('email', 'Email', 'required');
      		if ($this->form_validation->run() == FALSE) 
			{
				$data['MENU_1'] = 'Home';
				$data['MENU_2'] = 'Log in';
				$data['MENU_3'] = 'Sign Up';
				$data['COLOR'] = 'transparent';
        		$this->smarty->view('application/views/templates/login_template.tpl', $data); 
      		}
    	} 
  		public function login_action() 
    	{ 
    		$mail = $this->input->post('email');
     		$pass = $this->input->post('pwd'); 
     		$password = substr(md5($pass),0,32);
            
            	$FormData = array(
               		'email' => $mail,
              	 	'pass' => $password
               
           	); 
        	$tupple = $this->Blog_model->validate_user($FormData); 
        	if ($tupple == true) 
        	{ 
            		$data['MESSAGE'] = 'Welcome back! '.$_SESSION['name']; 
            		$this->smarty->view('message_template.tpl', $data); 
       		} 
        	if($tupple == false) 
        	{ 
					$data['COLOR'] = 'firebrick';
					$data['MESSAGE'] = 'Login Failed!';
					$data['MENU_1'] = 'Home';
					$data['MENU_2'] = 'Log in';
					$data['MENU_3'] = 'Sign Up';
					$data['email'] = $mail;
            		$this->smarty->view('login_template.tpl', $data); 
        	} 
        
		}
		public function post($blog_id = FALSE) 
 		{ 
			
  			$data['MENU_1'] = 'Home'; 
			$data['MENU_4'] = 'Post blog';
			//if(empty($_GET['blog_id'])){
			//	$blog_id=FALSE;
			//}
			//else
			//{
			//	$blog_id=$_GET['blog_id']; 
			//}	         
 			if($blog_id)
   			{ 
      			$tupple = $this->Blog_model->get_blog($blog_id); 
				$data['blog_id'] = $blog_id;
				$user = $tupple->user_id;
				
         		if($user == $_SESSION['id'])
				$data['BLOG'] = $tupple->content;
				
    		} 
    		$this->load->library('form_validation'); 
    		$this->form_validation->set_rules('content', 'Blog', 'required');
    		if ($this->form_validation->run() == FALSE) 
        	{   
          		$data['form_validation'] = validation_errors(); 
				$this->smarty->view('application/views/templates/blog_template.tpl', $data);  
			}
			else
			{
				if($blog_id == FALSE)
				{
					
         			$this->Blog_model->new_blog();
				 }
				elseif ($blog_id and ($_SESSION['id'] != $user) )
 				{
					$this->Blog_model->new_reply($blog_id);
 				} 
				else 
				{
					$this->Blog_model->update_blog($blog_id);
				}
				redirect('/blog'); 
			}
			
		}
		public function logout() 
		{ 
		  $this->session->sess_destroy(); 
		  $data['MESSAGE'] = 'See you back soon!' ;
		  $this->smarty->view('message_template.tpl', $data);    
		}    
    
    
}
?>