<?php
/* Smarty version 3.1.30, created on 2018-11-15 10:56:12
  from "/users/a54375/public_html/LAB9_10/application/views/templates/login_template.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5bed50cc32aaa2_20248021',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9278225472605e2008fbc2fc6e802a75d68376b5' => 
    array (
      0 => '/users/a54375/public_html/LAB9_10/application/views/templates/login_template.tpl',
      1 => 1542279297,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bed50cc32aaa2_20248021 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</head>
<body>

<nav class="navbar navbar-inverse" style=background-color:green;border-color:green;color:white;height:70px>
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="https://png.icons8.com/cotton/2x/golf-ball.png" style="height:60px;width: 60px;margin-top:5%">

    
</div>
    <ul class="nav navbar-nav">
	<!-- BEGIN TOP -->
      <li><a href="index" style="color:lightgray;font-size:20px;margin-top:4%;"><?php echo $_smarty_tpl->tpl_vars['MENU_1']->value;?>
</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="login" style="font-size:16px;margin-top:10%;"> <span class="glyphicon glyphicon-log-in"></span> <?php echo $_smarty_tpl->tpl_vars['MENU_2']->value;?>
</a></li>
      <li><a href="register" style="font-size:16px;margin-top:12%;"><?php echo $_smarty_tpl->tpl_vars['MENU_3']->value;?>
</a></li>
	<!-- END TOP -->

    </ul>
  </div>
</nav>


<div class="panel panel-default" style="background-color:<?php echo $_smarty_tpl->tpl_vars['COLOR']->value;?>
;color:whitesmoke;border:<?php echo $_smarty_tpl->tpl_vars['COLOR']->value;?>
">
  <h3 style="text-align: center"><?php echo $_smarty_tpl->tpl_vars['MESSAGE']->value;?>
</h3>
</div>
<!-- END MESSAGE -->

<!-- BEGIN MENU -->
<div class="panel panel-default" style="margin-left: 20%;margin-right: 20%;margin-top:2%;background-color:white;">
    <h1 style="text-align:center">Login</h1>
	<form action="login_action" method="post" $id="loginform">
    	<!-- BEGIN FORM -->
             <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" name="email" value="<?php echo $_smarty_tpl->tpl_vars['EMAIL']->value;?>
">
              </div>
              	<!-- END FORM -->
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input type="password" class="form-control" name="pwd">
        </div>
                <div class="align:center-block" style="margin-left:45%;">
            <button type="submit" class="btn btn-default" style="background-color:blue;color:white;margin-bottom:3%" formid="loginform">Go</button>
            <input type="checkbox" name="autologin" value="1"><text>Remember me</text>
	    <a href="password_reset.php">Forgot password?</a> 


        </div>
      </form>

</div>
<!-- END MENU -->
<footer>
  <div class="page-header">
    <div class="pull-left" style="margin-left:10%">
    <h6>2018 Desenvolvimento de Aplicações Web</h6>
    </div>
    <div class="pull-right" style="margin-right:10%">
    <h6 class="text-right" >Designed by Miguel Cristina</h6>
    </div>
    <div class="clearfix"></div>
  </div>
</footer>   
</div>
</body>
</html><?php }
}
