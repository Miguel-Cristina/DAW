<?php
/* Smarty version 3.1.30, created on 2018-11-30 13:21:39
  from "/users/a54375/public_html/LAB11A/application/views/templates/replies_template.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c013963358796_46916372',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7d376c401c34703d7e1f1ea293dfed1eb6154298' => 
    array (
      0 => '/users/a54375/public_html/LAB11A/application/views/templates/replies_template.tpl',
      1 => 1543584011,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c013963358796_46916372 (Smarty_Internal_Template $_smarty_tpl) {
?>


<?php
$__section_bl_0_saved = isset($_smarty_tpl->tpl_vars['__smarty_section_bl']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl'] : false;
$__section_bl_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['replies']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_bl_0_total = $__section_bl_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_bl'] = new Smarty_Variable(array());
if ($__section_bl_0_total != 0) {
for ($__section_bl_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] = 0; $__section_bl_0_iteration <= $__section_bl_0_total; $__section_bl_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']++){
?> 
<div class="panel panel-default" style="margin-left: 5%;margin-right: 5%;margin-top:2%;border-color:royalblue">
  <div class="row">
      <div class="col-lg-12"></div>
    <div style="text-align:center;margin-top: 2%;margin-bottom: 2%;"><?php echo $_smarty_tpl->tpl_vars['replies']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['content'];?>
</div>
    </div>
  <div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default" style="margin-left: 0.5%;margin-right: 0.5%;border-color: grey">
            <div class="panel-body" >
        <div class="row" style="margin-bottom: 0%">
            <div class="col-lg-2" style="text-align: center; color:green"><?php echo $_smarty_tpl->tpl_vars['replies']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['name'];?>
</div>
            <div class="col-lg-3" style="text-align: center">replied at: <?php echo $_smarty_tpl->tpl_vars['replies']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['created_at'];?>
</div>
        </div>
       </div>
      </div>
      </div>
  </div>
</div>

  <?php
}
}
if ($__section_bl_0_saved) {
$_smarty_tpl->tpl_vars['__smarty_section_bl'] = $__section_bl_0_saved;
}
?>

<?php }
}
