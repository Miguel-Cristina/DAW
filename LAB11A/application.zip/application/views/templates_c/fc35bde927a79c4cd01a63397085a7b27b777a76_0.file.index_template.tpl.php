<?php
/* Smarty version 3.1.30, created on 2018-11-30 13:23:03
  from "/users/a54375/public_html/LAB11A/application/views/templates/index_template.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c0139b7a80da5_11316581',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fc35bde927a79c4cd01a63397085a7b27b777a76' => 
    array (
      0 => '/users/a54375/public_html/LAB11A/application/views/templates/index_template.tpl',
      1 => 1543584103,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c0139b7a80da5_11316581 (Smarty_Internal_Template $_smarty_tpl) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Miguel Cristina's DAW Forum</title>
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</head>
<body>

<nav class="navbar navbar-inverse" style="background-color: green;border-color: green;color:white;height:70px ">
  <div class="container-fluid">
    <div class="navbar-header">
      <img src="https://png.icons8.com/cotton/2x/golf-ball.png" style="height:60px;width: 60px;margin-top:5%">
    </div>
    <ul class="nav navbar-nav">
       <!-- BEGIN TOP -->
      <li><a href="http://all.deei.fct.ualg.pt/~a54375/LAB11/index.php/blog/" style="color:lightgray;font-size:30px;margin-top:10%"><?php echo $_smarty_tpl->tpl_vars['MENU_1']->value;?>
</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="<?php echo $_smarty_tpl->tpl_vars['LINK']->value;?>
" style="font-size:15px;margin-top:10%"><span class="glyphicon glyphicon-log-out"></span> <?php echo $_smarty_tpl->tpl_vars['MENU_2']->value;?>
</a></li>
      <li><a href="<?php echo $_smarty_tpl->tpl_vars['LINK2']->value;?>
"style="font-size:15px;margin-top:10%"><?php echo $_smarty_tpl->tpl_vars['MENU_4']->value;?>
</a></li>
      <li><a href="#" style="font-size:15px;margin-top:7%"><?php echo $_smarty_tpl->tpl_vars['WELCOME']->value;
echo $_smarty_tpl->tpl_vars['USER']->value;?>
</a></li>
      <!-- END TOP -->

    </ul>
  </div>
</nav>
 
<div class="panel panel-default" style="margin-left: 5%;margin-right: 5%">

<div id="myCarousel" class="carousel slide" data-ride="carousel" margin:auto align:center>
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img class="center-block" src="https://detroit.carpe-diem.events/data/afisha/o/65/35/65350698cc.jpg" alt="Daw1">
    </div>

    <div class="item ">
      <img class="center-block" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTCyxx4qf--xp-2AGpCHY51lJbgy6MNkxCTCJOKJ3ZWtfPgZGCg" alt="Daw2">
    </div>

    <div class="item ">
      <img class="center-block"  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7DSgjlZDVy4JzBy9oY5GjLLkr_qxWWVf8gZPqDgNTwJgVTDomIg" alt="Daw3">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>


<?php echo '<script'; ?>
>
  function myToggle(id) {
				var b = document.getElementById("b"+id);
				var d = document.getElementById("d"+id);
				
				if(b.innerHTML=="Show replies"){
					d.style.display="block";
					b.innerHTML="Hide replies";
					var xtp=new XMLHttpRequest();
					xtp.onreadystatechange=function()
          {
						if(this.status==200)
							d.innerHTML = this.responseText;
					};
					xtp.open("GET","http://all.deei.fct.ualg.pt/~a54375/LAB11A/index.php/blog/replies/"+id,true);
          xtp.send();
				}
        else
        {
					d.style.display="none";
					b.innerHTML="Show replies";
				}
  }
<?php echo '</script'; ?>
>

<!-- BEGIN MENU -->
<?php
$__section_bl_0_saved = isset($_smarty_tpl->tpl_vars['__smarty_section_bl']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl'] : false;
$__section_bl_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['blogs']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_bl_0_total = $__section_bl_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_bl'] = new Smarty_Variable(array());
if ($__section_bl_0_total != 0) {
for ($__section_bl_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] = 0; $__section_bl_0_iteration <= $__section_bl_0_total; $__section_bl_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']++){
?> 
<div class="panel panel-default" style="margin-left: 5%;margin-right: 5%;margin-top:2%;border-color:green">
 
<div class="row">
    <div class="col-lg-12"></div>
  <div style="text-align:center;margin-top: 2%;margin-bottom: 2%;"><?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['content'];?>
</div>
  </div>
<div class="row">
  <div class="col-lg-12">
      <div class="panel panel-default" style="margin-left: 0.5%;margin-right: 0.5%;border-color: grey">
          <div class="panel-body" >
      <div class="row" style="margin-bottom: 0%">
          <div class="col-lg-2" style="text-align: center; color:chocolate"><?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['name'];?>
</div>
 	        <div class="col-lg-3" style="text-align: center">updated: <?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['updated_at'];?>
</div>
          <div class="col-lg-3" style="text-align: center">created: <?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['created_at'];?>
</div>
          <button id="b<?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['id'];?>
" onclick="myToggle('<?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['id'];?>
')">Show replies</button> 
      <?php if ($_smarty_tpl->tpl_vars['session_id']->value != 0 && $_smarty_tpl->tpl_vars['session_id']->value == $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['user_id']) {?>
          <a href="<?php echo $_smarty_tpl->tpl_vars['LINK2']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['id'];?>
" class="col-lg-3" style="text-align: right;color:green"> Update blog </a>
      <?php } elseif ($_smarty_tpl->tpl_vars['session_id']->value != 0 && $_smarty_tpl->tpl_vars['session_id']->value != $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['user_id']) {?>  
          <a href="<?php echo $_smarty_tpl->tpl_vars['LINK2']->value;?>
/<?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['id'];?>
" class="col-lg-3" style="text-align: right;color:royalblue">Reply to blog</a> &nbsp;
	    <?php } else { ?>
     		 &nbsp; &nbsp;
    	  <?php }?>
      </div>
      
     </div>
     
    </div>
    <div id="d<?php echo $_smarty_tpl->tpl_vars['blogs']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_bl']->value['index'] : null)]['id'];?>
">
        
    </div>
    </div>
</div>
</div>
<?php
}
}
if ($__section_bl_0_saved) {
$_smarty_tpl->tpl_vars['__smarty_section_bl'] = $__section_bl_0_saved;
}
?>
<!-- END MENU -->
<footer>
        <div class="page-header">
                <div class="pull-left" style="margin-left:10%">
                <h6>2018 Desenvolvimento de Aplicacoes Web</h6>
                </div>
                <div class="pull-right" style="margin-right:10%">
                <h6 class="text-right" >Designed by Miguel Cristina</h6>
                </div>
                <div class="clearfix"></div>
              </div>
              
</footer>   
</body>
</html><?php }
}
