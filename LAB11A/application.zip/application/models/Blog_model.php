<?php
class Blog_model extends CI_Model {
 	public function __construct()
 	{
 		$this->load->database();
 	}
 	public function get_posts()
 	{
		$sql = "SELECT o.name, c.user_id, c.content, c.updated_at, c.created_at, c.id
            FROM microposts c
            INNER JOIN users o
            ON c.user_id = o.id
		ORDER BY c.updated_at DESC;";
 
		$query = $this->db->query($sql);
		return $query->result_array();
 	}
	public function get_blog($blog_id)
	{
   	 	$content  = "SELECT * FROM microposts WHERE id = '$blog_id' ORDER BY updated_at;";
    	$query = $this->db->query($content);
   		$row = $query->row();
    		return $row;
	}
	public function get_total($user_id)
	{
   	 	$content  = "SELECT COUNT(*) as [Count] FROM microposts WHERE user_id = '$user_id';";
    	$query = $this->db->query($content);
   		$row = $query->row();
    		return $row;
    }
    public function register_user($data) 
    { 
       		$query = "INSERT into users(name, email, created_at, updated_at, password_digest) VALUES('".$data['name']."','".$data['email']."','".$data['update']."','".$data['update']."','".$data['pass']."');"; 
      			return $this->db->query($query); 
    }
	public function validate_user($data)
	{
     		$condition = "email =" . "'" . $data['email'] . "' AND " . "password_digest =" . "'" . $data['pass'] . "'";
     		$this->db->select('*')->from('users')->where($condition);
    		$query = $this->db->get();
     		if($query->num_rows() == 1)
		{
       		        //session_start();
      			$tuple = $query->row_array();
        		$_SESSION['id'] = $tuple['id'];
         		$_SESSION['name'] = $tuple['name'];
        		$_SESSION['email'] = $tuple['email'];
         			return true;
     		}
     		else
		{
        		 return false;
     		}
	 }
	 public function new_blog(){
     
		$in = $this->input->post('content');
		$userId = $_SESSION['id'];
		$update = date("Y-m-d H:i:s");
		  
	   $values = "INSERT INTO microposts(content, user_id, created_at, updated_at)
					VALUES ('$in', '$userId', '$update', '$update');";
		
		$query = $this->db->query($values);
		echo "did something";
	}
	 public function update_blog($blog_id){
     
		$in = $this->input->post('content');
		$userId = $_SESSION['id'];
		$update = date("Y-m-d H:i:s"); 
	    $values = "UPDATE microposts 
					SET content='$in', updated_at='$update' 
					WHERE id='$blog_id';";
		
		$query = $this->db->query($values);

	}

	public function new_reply($blog_id){
		$in = $this->input->post('content');
		$userId = $_SESSION['id'];
		$update = date("Y-m-d H:i:s");
		
		$values = "INSERT INTO replies(content, user_id, micropost_id, created_at)
					 VALUES ('$in', '$userId', '$blog_id', '$update');";
		
		$query = $this->db->query($values);
	} 
	
	public function get_replies($id) { 
		
		$sql="SELECT * FROM replies AS r, users AS u WHERE r.micropost_id = '$id' AND r.user_id = u.id"; 
		$query = $this->db->query($sql); 
		return $query->result_array(); 
	}
	

}
?>